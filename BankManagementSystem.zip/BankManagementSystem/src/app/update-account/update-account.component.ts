import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { FormGroup, NgForm, Validators } from '@angular/forms';
import { User } from '../auth/user.model';
import { AuthResponseData, AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-update-account',
  templateUrl: './update-account.component.html',
  styleUrls: ['./update-account.component.css']
})
export class UpdateAccountComponent implements OnInit {

    userForm: FormGroup;
    private users: User[] = [];
    constructor(private formBuilder: FormBuilder, private http: HttpClient, private router: Router) { }

    states: Array<any>;

    countryList: Array<any> = [
      { name: 'India', states: ['Andhra Pradesh', 'Andaman and Nicobar Islands', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chandigarh', 'Chhattisgarh', 'Delhi', 'Goa', 'Gujarat', 'Haryana',
      'Himachal Pradesh', 'Jammu and Kashmir', 'Jharkhand', 'Karnataka', 'Kerala', 'Ladakh', 'Lakshadweep', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 
      'Nagaland', 'Odisha', 'Puducherry', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 
      'West Bengal'] },
    ];

    changeCountry(count) {
      this.states = this.countryList.find(con => con.name == count).states;
    }

    ngOnInit() {
        this.http
          .get<User[]>('https://bank-management-system-eebb2-default-rtdb.firebaseio.com/users.json')
          .subscribe(users => {
            this.users = users;
            console.log('this.users.email',this.users['email']);
            this.changeCountry('India');

            if(this.users[0] != null) {
              this.userForm.setValue({
                email: this.users[0]['email'],
                password: this.users[0]['password'],
                name: this.users[0]['name'],
                userName: this.users[0]['userName'],
                guardianType: this.users[0]['guardianType'],
                guardianName: this.users[0]['guardianName'],
                citizenship: this.users[0]['citizenship'],
                country: this.users[0]['country'],
                state: this.users[0]['state'],
                address: this.users[0]['address'],
                maritalStatus: this.users[0]['maritalStatus'],
                gender: this.users[0]['gender'],
                contactNo: this.users[0]['contactNo'],
                dob: this.users[0]['dob'],
                registrationDate: this.users[0]['registrationDate'],
                accountType: this.users[0]['accountType'],
                branchName: this.users[0]['branchName'],
                citizenStatus: this.users[0]['citizenStatus'],
                depositAmount: this.users[0]['depositAmount'],
                idProofType: this.users[0]['idProofType'],
                idDocumentNo: this.users[0]['idDocumentNo'],
                refAccountHolderName: this.users[0]['refAccountHolderName'],
                refAccountHolderAccNo: this.users[0]['refAccountHolderAccNo'],
                refAccountHolderAdd: this.users[0]['refAccountHolderAdd']
              });
            }
            else {
              this.userForm.setValue({
                email: this.users['email'],
                password: this.users['password'],
                name: this.users['name'],
                userName: this.users['userName'],
                guardianType: this.users['guardianType'],
                guardianName: this.users['guardianName'],
                citizenship: this.users['citizenship'],
                country: this.users['country'],
                state: this.users['state'],
                address: this.users['address'],
                maritalStatus: this.users['maritalStatus'],
                gender: this.users['gender'],
                contactNo: this.users['contactNo'],
                dob: this.users['dob'],
                registrationDate: this.users['registrationDate'],
                accountType: this.users['accountType'],
                branchName: this.users['branchName'],
                citizenStatus: this.users['citizenStatus'],
                depositAmount: this.users['depositAmount'],
                idProofType: this.users['idProofType'],
                idDocumentNo: this.users['idDocumentNo'],
                refAccountHolderName: this.users['refAccountHolderName'],
                refAccountHolderAccNo: this.users['refAccountHolderAccNo'],
                refAccountHolderAdd: this.users['refAccountHolderAdd']
              });
            }

          });
          
        this.userForm = this.formBuilder.group({
          email: ['', [Validators.required, Validators.email]],
          password: ['', [Validators.required]],
          name: ['', [Validators.required]],
          userName: ['', [Validators.required]],
          guardianType: ['', [Validators.required]],
          guardianName: ['', [Validators.required]],
          citizenship: ['', [Validators.required]],
          country: ['', [Validators.required]],
          state: ['', [Validators.required]],
          address: ['', [Validators.required]],
          maritalStatus: ['', [Validators.required]],
          gender: ['', [Validators.required]],
          contactNo: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
          dob: ['', [Validators.required]],
          registrationDate: ['', [Validators.required]],
          accountType: ['', [Validators.required]],
          branchName: ['',  [Validators.required]],
          citizenStatus: ['', [Validators.required]],
          depositAmount: ['', [Validators.required]],
          idProofType: ['', [Validators.required]],
          idDocumentNo: ['', [Validators.required]],
          refAccountHolderName: ['', [Validators.required]],
          refAccountHolderAccNo: ['', [Validators.required]],
          refAccountHolderAdd: ['', [Validators.required]]
        });

    }

    onSubmit(){
      console.log('form value after change', this.userForm.value);
      console.log('form value after change', this.userForm.value.address);

      this.users = this.userForm.value;
      
      this.http
        .put('https://bank-management-system-eebb2-default-rtdb.firebaseio.com/users.json', this.users)
        .subscribe(response => {
          console.log(response);
        });

        this.router.navigate(['/update-success']);
      }

      getToday(): string {
        return new Date().toISOString().split('T')[0]
     }

}
