import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError, tap } from 'rxjs/operators';
import { throwError, BehaviorSubject } from 'rxjs';

import { User } from './user.model';

export interface AuthResponseData {
  idToken: string;
  email: string;
  refreshToken: string;
  expiresIn: string;
  localId: string
  registered?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  user = new BehaviorSubject<User>(null);
  private tokenExpirationTimer: any;

  constructor(private http: HttpClient, private router: Router) { }
  
  signup(email: string, password: string) {
    return this.http.post<AuthResponseData>(
      'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyCZqtwh0lQa5mW6UwuISAbd58IFLKksIRk',
      {
        email: email,
        password: password,
        returnSecureToken: true
      }
    )
    .pipe(
      catchError(this.handleError), 
      tap(resData => {
        this.handleAuthentication(
          resData.email, 
          resData.localId, 
          resData.idToken, 
          +resData.expiresIn
        );        
      })
    );
  }

login(email: string, password: string) {
  localStorage.clear();
  localStorage.setItem('email', email);
  return this.http.post<AuthResponseData>('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyCZqtwh0lQa5mW6UwuISAbd58IFLKksIRk', 
  {
    email: email, 
    password: password,
    returnSecureToken: true
  })
  .pipe(
    catchError(this.handleError), 
    tap(resData => {
      this.handleAuthentication(
        resData.email, 
        resData.localId, 
        resData.idToken, 
        +resData.expiresIn
      );        
    })
  );
}

autoLogin() {
  const userData: {
    email: string;
    id: string;
    _token: string;
    _tokenExpirationDate: string;
  } = JSON.parse(localStorage.getItem('userData'));
  if (!userData) {
    return;
  }

  const loadedUser = new User(
    userData.email,
    userData.id,
    userData._token,
    new Date(userData._tokenExpirationDate)
  );

  if (loadedUser.token) {
    this.user.next(loadedUser);
    // calculation the remaining time of token expiration (future expiration date - current date)
    const expirationDuration = new Date(userData._tokenExpirationDate).getTime() - new Date().getTime();
    this.autoLogout(expirationDuration);
  }

}

logout() {
  localStorage.clear();
  this.user.next(null);
  this.router.navigate(['/auth']);
  localStorage.removeItem('userData');

  if (this.tokenExpirationTimer) {
    clearTimeout(this.tokenExpirationTimer);
  }
  this.tokenExpirationTimer = null;
}

autoLogout(expirationDuration: number) {
  //to logout after 60 mins (issued by token) ; expirationDuration we recive is in miliseconds
  console.log(expirationDuration);
  this.tokenExpirationTimer = setTimeout(() => {
    this.logout();
  }, expirationDuration);
}

private handleAuthentication(email: string, userId: string, token: string, expiresIn: number) {
  const expirationDate = new Date(
    new Date().getTime() + expiresIn * 1000
  );
  const user = new User(email, userId, token, expirationDate);
  this.user.next(user);
  this.autoLogout(expiresIn * 1000); // expiresIn is in seconds * 1000 gives us miliseconds
  localStorage.setItem('userData', JSON.stringify(user));  //JSON.stringify converts javascript object to a string text and v r finally storing in local storage
}

private handleError(errorRes: HttpErrorResponse) {  //common code for error handling logic (for sign up and login methods)
  let errorMessage = 'An unknown error occured!';
  if (!errorRes.error || !errorRes.error.error) {    //if we have network related error
    return throwError(errorMessage);
  }
  switch (errorRes.error.error.message) {     //email already exist check
    case 'EMAIL_EXISTS':
      errorMessage = 'This email already exists.';
      break;
    case 'EMAIL_NOT_FOUND':
      errorMessage = 'This email does not exist.';
      break;
    case 'INVALID_PASSWORD':
      errorMessage = 'This password is not correct.';
      break;
  }
  return throwError(errorMessage); 
}

}

