import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-success',
  templateUrl: './update-success.component.html',
  styleUrls: ['./update-success.component.css']
})
export class UpdateSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
