import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-apply-loan',
  templateUrl: './apply-loan.component.html',
  styleUrls: ['./apply-loan.component.css']
})
export class ApplyLoanComponent implements OnInit {

  loanForm: FormGroup;
  educationLoan: boolean = false;
  otherLoanType: boolean = false;
  showForm: boolean = true;
  amount: number;
  duration: number;
  selectedValue: string;

  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.loanForm = this.formBuilder.group({
      loanAmount: ['', [Validators.required]],
      loanDuration: ['',[Validators.required]],
      loanApplyDate: ['', [Validators.required]],
      loanIssueDate: ['',[Validators.required]],
      roi: ['',[Validators.required]],
      loanType: ['',[Validators.required]],
      courseFee: ['',[Validators.required]],
      course: ['',[Validators.required]],
      fatherName: ['',[Validators.required]],
      fatherOccupation: ['',[Validators.required]],
      fatherTotalExp: ['',[Validators.required]],
      fatherCCExp: ['',[Validators.required]],
      rationCardNo: ['',[Validators.required]],
      annualIncomeEducation: ['',[Validators.required]],
      annualIncomeOther: ['',[Validators.required]],
      companyName: ['',[Validators.required]],
      designation: ['',[Validators.required]],
      totalExp: ['',[Validators.required]],
      expCurrent: ['',[Validators.required]],
    });

  }

  onSubmit() {
    console.log('loanDetails', this.loanForm.value);
    this.amount = this.loanForm.value['loanAmount'];
    this.duration = this.loanForm.value['loanDuration'];
    this.showForm = false;
  }

  getToday(): string {
    return new Date().toISOString().split('T')[0]
 }

  selectchange(args: any){ 
    this.selectedValue = args.target.value;
    // const selectedName = args.target.options[args.target.selectedIndex].text;

    if(this.selectedValue === "Education") {
      this.educationLoan = true;
      this.otherLoanType = false;
      this.loanForm.patchValue({
        roi: 8,
      });
    }
    else {
      this.otherLoanType = true;
      this.educationLoan = false;
      this.loanForm.patchValue({
        roi: 12,
      });
    }
  } 

}
