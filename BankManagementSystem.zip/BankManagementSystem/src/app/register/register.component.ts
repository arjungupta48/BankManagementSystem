import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs'; 

import { AuthService, AuthResponseData } from '../auth/auth.service';
import { User } from './user.model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  authForm: FormGroup;
  isLoginMode = true;
  isLoading = false;
  error: string = null;
  signedUp: boolean = false;
  custumerId: string;

  private users: User[] = [];

  constructor(private formBuilder: FormBuilder, private authServie: AuthService, private router: Router, private http: HttpClient) { }

  states: Array<any>;

  countryList: Array<any> = [
    { name: 'India', states: ['Andhra Pradesh', 'Andaman and Nicobar Islands', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chandigarh', 'Chhattisgarh', 'Delhi', 'Goa', 'Gujarat', 'Haryana',
     'Himachal Pradesh', 'Jammu and Kashmir', 'Jharkhand', 'Karnataka', 'Kerala', 'Ladakh', 'Lakshadweep', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 
    'Nagaland', 'Odisha', 'Puducherry', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 
    'West Bengal'] },
  ];

  changeCountry(count) {
    this.states = this.countryList.find(con => con.name == count).states;
  }

  ngOnInit(): void {
    this.authForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
      name: ['', [Validators.required]],
      userName: ['', [Validators.required]],
      guardianType: ['', [Validators.required]],
      guardianName: ['', [Validators.required]],
      citizenship: ['', [Validators.required]],
      country: ['', [Validators.required]],
      state: ['', [Validators.required]],
      address: ['', [Validators.required]],
      maritalStatus: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      contactNo: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      dob: ['', [Validators.required]],
      registrationDate: ['', [Validators.required]],
      accountType: ['', [Validators.required]],
      branchName: ['',  [Validators.required]],
      citizenStatus: ['', [Validators.required]],
      depositAmount: ['', [Validators.required]],
      idProofType: ['', [Validators.required]],
      idDocumentNo: ['', [Validators.required]],
      refAccountHolderName: ['', [Validators.required]],
      refAccountHolderAccNo: ['', [Validators.required]],
      refAccountHolderAdd: ['', [Validators.required]]
      });
  }

  onSubmit() {
    this.signedUp = false;
    console.log(this.authForm.value);

    if(!this.authForm.valid) { //we already disable button when form is not valid, but can be changed from Browser Developer Tools. Hence this logic
      return;
    }

    this.users.push(this.authForm.value);
    console.log('users array', this.users);

    this.http
        .put('https://bank-management-system-eebb2-default-rtdb.firebaseio.com/users.json', this.users)
        .subscribe(response => {
          console.log(response);
        });

    const email = this.authForm.value.email;
    const passowrd = this.authForm.value.password; 

    let authObs: Observable<AuthResponseData>;   //authObs to reduce duplicate code in both subscirbe method in if and else case. Now we subscribe after if else condition. Hence, reducing same repetitive code

    this.isLoading = true;

    authObs = this.authServie.signup(email, passowrd);

    authObs.subscribe(
      resData => {
        console.log(resData);
        this.signedUp = true;
        var custIdPrefix = "R-"
        var randomId = Math.floor(100 + Math.random() * 900);
        var custID = custIdPrefix.concat(randomId.toString());
        this.custumerId = custID;
        this.isLoading = false;
    }, 
    errorMessage => {
      console.log(errorMessage);
      this.error = errorMessage;
      this.isLoading = false;
    }
  );

    // this.authForm.reset();
  }

  getToday(): string {
    return new Date().toISOString().split('T')[0]
 }

}

