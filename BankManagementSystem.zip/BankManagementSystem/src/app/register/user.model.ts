export class User {
    public email: string;
    public passowrd: string;
    public name: string;
    public userName: string;
    public guardianType: string;
    public guardianName: string;
    public citizenship: string;
    public country: string;
    public state: string;
    public address: string;
    public maritalStatus: string;
    public gender: string;
    public contactNo: string;
    public dob: string;
    public registrationDate: string;
    public accountType: string;
    public branchName: string;
    public citizenStatus: string;
    public depositAmount: string;
    public idProofType: string;
    public idDocumentNo: string;
    public refAccountHolderName: string;
    public refAccountHolderAccNo: string;
    public refAccountHolderAdd: string;

    constructor(email:string, passowrd: string, name: string, userName: string, guardianType: string, guardianName: string, citizenship: string,
        country: string, state: string, address: string, maritalStatus: string, gender: string, contactNo: string, dob: string, registrationDate: string,
        accountType: string, branchName: string, citizenStatus: string, depositAmount: string, idProofType: string, idDocumentNo: string,
        refAccountHolderName: string, refAccountHolderAccNo: string, refAccountHolderAdd: string) {
        this.email = email;
        this.passowrd = passowrd;
        this.name = name;
        this.userName = userName;
        this.guardianType = guardianType
        this.guardianName = guardianName;
        this.citizenship = citizenship;
        this.country = country;
        this.state = state;
        this.address = address;
        this.maritalStatus = maritalStatus;
        this.gender = gender;
        this.contactNo = contactNo;
        this.dob = dob;
        this.registrationDate = registrationDate;
        this.accountType = accountType;
        this.branchName = branchName;
        this.citizenStatus = citizenStatus;
        this.depositAmount = depositAmount;
        this.idProofType = idProofType;
        this.idDocumentNo = idDocumentNo;
        this.refAccountHolderName = refAccountHolderName;
        this.refAccountHolderAccNo = refAccountHolderAccNo;
        this.refAccountHolderAdd = refAccountHolderAdd;
    }
}