import { NgModule } from "@angular/core";
import { Routes, RouterModule } from '@angular/router';

import { AuthComponent } from './auth/auth.component';
import { AuthGuard } from './auth/auth.guard';
import { RegisterComponent } from './register/register.component';
import { UpdateAccountComponent } from "./update-account/update-account.component";
import { ApplyLoanComponent } from "./apply-loan/apply-loan.component";
import { UpdateSuccessComponent } from "./update-success/update-success.component";

const appRoutes: Routes = [
    { path: '', redirectTo: '/apply-loan', pathMatch: 'full' },
    { path: 'apply-loan', component: ApplyLoanComponent, canActivate: [AuthGuard] },
    { path: 'account-update', component: UpdateAccountComponent, canActivate: [AuthGuard] },
    { path: 'auth', component: AuthComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'update-success', component: UpdateSuccessComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)],
    exports: [RouterModule]
})

export class AppRoutingModule {

}
